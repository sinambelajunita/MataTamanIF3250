<html>
<head>
	<title>MataTaman</title>
	<!-- <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" /> -->
	<link rel="stylesheet" href="css/style.css" />
</head>

<body>
	<div class="container">
		<div class="header">
			<div class="left-header">
				<img src="images/logobandung.png" >.
			</div>
			<div class="right-header">
				MataTaman
			</div>
		</div>
		<div class="content">
			<div class="aduan">
				<div class="form_login">
					<b>Masukkan password untuk admin</b> <br><br>
					Password : <input type="password" name="password"><br><br>
					<button type="submit" value="login">Login</button>
				</div>
			</div>
		</div>
		<div class="footer">
			ini footer
		</div>



	</div>
</body>





</html>